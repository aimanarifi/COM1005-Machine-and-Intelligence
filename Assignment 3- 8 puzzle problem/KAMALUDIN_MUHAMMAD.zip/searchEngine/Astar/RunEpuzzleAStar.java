public class RunEpuzzleAStar {
	
	public static void main(String[] arg) {
		
		//Specify seed and diff
		int seed = 2022; //change seed here
		int difficulty = 9; //change difficulty here
		String remCostCalcMethod = "manhattan"; // manhattan/hamming
		
		//set fixed layouts as in problemsheet
		int[][] p1 = {{1,0,3},{4,2,6},{7,5,8}};
		int[][] p2 = {{4,1,3},{7,2,5},{0,8,6}};		
		int[][] p3 = {{2,3,6},{1,5,8},{4,7,0}};
		
		EpuzzGen puzz = new EpuzzGen(seed);
		
		int[][] puzzleStartingLayout = puzz.puzzGen(difficulty);// use this for randomized puzzle
		//int[][] puzzleStartingLayout = p2;
		int[][] target = puzz.tar;
		
		//Search execution
		EpuzzleSearch searcher = new EpuzzleSearch( puzzleStartingLayout, target, puzz, remCostCalcMethod);
		EpuzzleState startingState = new EpuzzleState(puzzleStartingLayout, searcher);
		
		//Print output
		System.out.print(searcher.runSearch(startingState, "AStar"));
	}
	
}

